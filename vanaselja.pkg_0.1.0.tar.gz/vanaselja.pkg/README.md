# vanaselja.pkg

## An R package for processing darter data

An R package to process darter data. Most functions accept any functional input and allow users to create graphs and calculate a wide variety of data relating to abiotic and biotic characteristics. Uses can use this package to perform a wide variety of statistic analyses, does not always need to  reflect fish.

Functions:
bar_graph()
clean_data()
filter_sexes()
linear_model()
plot_data()
summarize_value()